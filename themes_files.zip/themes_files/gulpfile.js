'use strict';

// Include Gulp & Tools We'll Use

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var runSequence = require('run-sequence');
var autoprefixer = require('gulp-autoprefixer');

var onError = function (err) {
    $.util.beep();
    console.log(err);
    this.emit('end');
};

/*
* -- SASS
*/
// Compile and Automatically Prefix Stylesheets
gulp.task('styles', function () {
    // For best performance, don't add Sass partials to `gulp.src`
    return gulp.src([
        'scss/style.scss'
    ])
    .pipe($.plumber({
        errorHandler: onError
    }))
    .pipe($.changed('sass', {extension: '.scss'}))
    .pipe($.sourcemaps.init())
    .pipe($.sass())
    .pipe(autoprefixer({
        browsers: ['last 2 versions'],
        cascade: false
    }))
    .pipe($.sourcemaps.write('maps'))
    .pipe(gulp.dest('css'))
    .pipe($.size({title: 'SASS'}))
    .on('end', function(){ console.log('Build Styles done.'); });
});
/*
 * -- END SASS
 */

/*
 * -- TASKs
 */
gulp.task('default', function (cb) {
    runSequence('styles', cb);
});

gulp.task('clear-cache', function (done) {
    return $.cache.clearAll(done);
});
gulp.task('watch', ['default'], function () {
    /*$.watch('./sass/!**!/!*.sccs', function () {
        gulp.start('styles');
    });*/
    gulp.watch('./scss/**/*.scss', ['styles']);
});


/*
 * -- END TASKs
 */